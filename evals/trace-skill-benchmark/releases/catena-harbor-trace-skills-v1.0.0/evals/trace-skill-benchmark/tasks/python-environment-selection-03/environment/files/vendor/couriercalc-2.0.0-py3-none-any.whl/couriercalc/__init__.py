__version__='2.0.0'
def summarize(items):
    return sum(items)*4
