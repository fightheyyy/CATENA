#!/bin/bash
set -euo pipefail
python3 /tests/verify.py
